# Myat Ma De May Phuu Ngon
# 26002304901

# This was used in early testing period and to setup the correct camera positions. Used depth camera.

import cv2
import mediapipe as mp
import numpy as np
import pyrealsense2 as rs

# Initialize RealSense camera pipeline
pipeline = rs.pipeline()
config = rs.config()

# Start the camera, enable both depth and color streams at 640x480 resolution, 30 FPS
config.enable_stream(rs.stream.depth, 640, 480, rs.format.z16, 30)
config.enable_stream(rs.stream.color, 640, 480, rs.format.bgr8, 30)

# Start streaming
pipeline.start(config)

# align depth frames to color frames for pixel correspondence
align = rs.align(rs.stream.color) 

# Initialize MediaPipe Hands for hand landmark detection
mp_hands = mp.solutions.hands
mp_drawing = mp.solutions.drawing_utils
hands = mp_hands.Hands(
    max_num_hands=1,                        # for one hand
    min_detection_confidence=0.7,           # confidence threshold for detection
    min_tracking_confidence=0.5             # confidence threshold for tracking
)

try:
    while True:
        # Wait for frames: depth and color
        frames = pipeline.wait_for_frames()
        aligned_frames = align.process(frames)

        depth_frame = aligned_frames.get_depth_frame()
        color_frame = aligned_frames.get_color_frame()

        # Skip if no valid frames
        if not depth_frame or not color_frame:
            print("Skipping: Frame not ready")
            continue

        # Convert RealSense frame to numpy array for OpenCV
        color_image = np.asanyarray(color_frame.get_data())
        frame_rgb = cv2.cvtColor(color_image, cv2.COLOR_BGR2RGB)

        if frame_rgb is None:
            print("RGB frame is None")
            continue

        # MediaPipe Hand Tracking
        results = hands.process(frame_rgb)

        if results.multi_hand_landmarks:
            for hand_landmarks in results.multi_hand_landmarks:
                # Draw hand landmarks and connections
                mp_drawing.draw_landmarks(color_image, hand_landmarks, mp_hands.HAND_CONNECTIONS)

                # Extract index finger tip coordinates
                h, w, _ = color_image.shape
                index_finger_tip = hand_landmarks.landmark[8] #index finger
                cx = int(index_finger_tip.x * w)
                cy = int(index_finger_tip.y * h)

                # Ensure coordinates are inside frame
                cx = np.clip(cx, 0, w - 1)
                cy = np.clip(cy, 0, h - 1)

                # Get depth value in meters and convert to mm
                depth = depth_frame.get_distance(cx, cy)
                depth_mm = depth * 1000

                # Draw circle on fingertip and depth info
                cv2.circle(color_image, (cx, cy), 8, (0, 255, 0), -1)
                cv2.putText(color_image, f"Depth: {depth_mm:.1f} mm", (cx + 10, cy - 10),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 255), 1)

        # Show image
        cv2.imshow("RealSense + MediaPipe Hand Tracking", color_image)

        # Exit with 'q'
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

except Exception as e:
    print(f"Exception occurred: {e}")

finally:
    # Stop camera pipline and close OpenCV window
    print("Stopping camera and closing windows")
    pipeline.stop()
    cv2.destroyAllWindows()

# last camera position : p5 - depth 577 with flat fingers positions