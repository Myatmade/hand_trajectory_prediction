# Myat Ma De May Phuu Ngon
# 26002304901

# This code is used to detect two robots' positions according to their attached corresponding markers and one hand with emphasis on index finger.
# It gives x,y and z(true depth from camera) every frame for each robot.
# It also detects the index finger tip position and gives its x,y,z coordinates.

import cv2
import cv2.aruco as aruco
import mediapipe as mp
import pyrealsense2 as rs
import numpy as np

# --- RealSense Setup ---
pipeline = rs.pipeline()
config = rs.config()
config.enable_stream(rs.stream.depth, 640, 480, rs.format.z16, 30)
config.enable_stream(rs.stream.color, 640, 480, rs.format.bgr8, 30)
pipeline.start(config)

align = rs.align(rs.stream.color)

# --- ArUco Marker Setup ---
aruco_dict = aruco.getPredefinedDictionary(aruco.DICT_4X4_1000)
parameters = aruco.DetectorParameters()
marker_to_robot = {
    50: "robot_1",
    51: "robot_2"
}

# --- MediaPipe Hand Setup ---
mp_hands = mp.solutions.hands
mp_drawing = mp.solutions.drawing_utils
hands = mp_hands.Hands(
    max_num_hands=1,
    min_detection_confidence=0.7,
    min_tracking_confidence=0.5
)

try:
    while True:
        frames = pipeline.wait_for_frames()
        aligned = align.process(frames)
        depth_frame = aligned.get_depth_frame()
        color_frame = aligned.get_color_frame()
        if not depth_frame or not color_frame:
            continue

        color_image = np.asanyarray(color_frame.get_data())
        depth_image = np.asanyarray(depth_frame.get_data())

        ### ---- ArUco Detection ---- ###
        corners, ids, _ = aruco.detectMarkers(color_image, aruco_dict, parameters=parameters)
        if ids is not None:
            for i, marker_id in enumerate(ids.flatten()):
                if marker_id not in marker_to_robot:
                    continue

                robot_name = marker_to_robot[marker_id]
                corner = corners[i][0]
                cx = int(np.mean(corner[:, 0]))
                cy = int(np.mean(corner[:, 1]))

                depth = depth_frame.get_distance(cx, cy)
                intrinsics = depth_frame.profile.as_video_stream_profile().intrinsics
                x, y, z = rs.rs2_deproject_pixel_to_point(intrinsics, [cx, cy], depth)

                # Output & draw
                print(f"[{robot_name}] Position: x={x:.3f}, y={y:.3f}, z={z:.3f}")
                aruco.drawDetectedMarkers(color_image, [corners[i]], ids[i])
                cv2.circle(color_image, (cx, cy), 5, (0, 255, 0), -1)
                cv2.putText(color_image, f"{robot_name} ({x:.2f},{y:.2f},{z:.2f})",
                            (cx, cy - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 1)

        ### ---- Hand Detection ---- ###
        frame_rgb = cv2.cvtColor(color_image, cv2.COLOR_BGR2RGB)
        results = hands.process(frame_rgb)

        if results.multi_hand_landmarks:
            for hand_landmarks in results.multi_hand_landmarks:
                mp_drawing.draw_landmarks(color_image, hand_landmarks, mp_hands.HAND_CONNECTIONS)

                h, w, _ = color_image.shape
                index_finger_tip = hand_landmarks.landmark[8]
                cx = int(index_finger_tip.x * w)
                cy = int(index_finger_tip.y * h)
                cx = np.clip(cx, 0, w - 1)
                cy = np.clip(cy, 0, h - 1)

                depth = depth_frame.get_distance(cx, cy)
                depth_mm = depth * 1000
                intrinsics = depth_frame.profile.as_video_stream_profile().intrinsics
                x, y, z = rs.rs2_deproject_pixel_to_point(intrinsics, [cx, cy], depth)

                # Output & draw
                print(f"[hand_tip] Position: x={x:.3f}, y={y:.3f}, z={z:.3f}")
                cv2.circle(color_image, (cx, cy), 8, (255, 0, 0), -1)
                cv2.putText(color_image, f"Hand ({x:.2f},{y:.2f},{z:.2f})",
                            (cx + 10, cy - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 0), 1)

        # Show combined output
        cv2.imshow("Hand + Robot Detection", color_image)
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

finally:
    pipeline.stop()
    cv2.destroyAllWindows()
